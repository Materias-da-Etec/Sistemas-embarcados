#define mA 2
#define mB 4
#define variv 3
#define variav2 7
#define mA2 6
#define mB2 5

void mudar_estado(int motorA,int motorB,int motorA2,int motorB2,char estado[],int tempo){
  if (strcmp(estado, "frente")==0){
   digitalWrite(mA,HIGH);
   digitalWrite(mB,LOW);
   digitalWrite(mA2,HIGH);
   digitalWrite(mB2,LOW);
   delay(tempo);
  }
  else if(strcmp(estado,"esquerda")==0){
   digitalWrite(mA,LOW);
   digitalWrite(mB,LOW);
   digitalWrite(mA2,HIGH);
   digitalWrite(mB2,LOW);
   delay(tempo);
  }
  else if(strcmp(estado,"direita")==0){
   digitalWrite(mA,HIGH);
   digitalWrite(mB,LOW);
   digitalWrite(mA2,LOW);
   digitalWrite(mB2,LOW);
   delay(tempo);
  }
  else if(strcmp(estado,"tras")==0){
   digitalWrite(mA,LOW);
   digitalWrite(mB,HIGH);
   digitalWrite(mA2,LOW);
   digitalWrite(mB2,HIGH);
   delay(tempo);
  }
  else if(strcmp(estado,"parado")==0){
   digitalWrite(mA,LOW);
   digitalWrite(mB,LOW);
   digitalWrite(mA2,LOW);
   digitalWrite(mB2,LOW);
   delay(tempo);
  }
  
  
}

void setup()
{
  pinMode(mA2,OUTPUT);
  pinMode(mB2,OUTPUT);
  pinMode(variav2,OUTPUT);
  pinMode(mA, OUTPUT);
  pinMode(mB,OUTPUT);
  pinMode(variv,OUTPUT);
}

void loop()
{
 analogWrite(variv,255);
 analogWrite(variav2,255);
 mudar_estado(mA,mB,mA2,mB2,"frente",3000);
 mudar_estado(mA,mB,mA2,mB2,"esquerda",1000);
 mudar_estado(mA,mB,mA2,mB2,"frente",3000);
 mudar_estado(mA,mB,mA2,mB2,"esquerda",1000);
 mudar_estado(mA,mB,mA2,mB2,"frente",5000);
 mudar_estado(mA,mB,mA2,mB2,"direita",1000);
 mudar_estado(mA,mB,mA2,mB2,"frente",4000);
 mudar_estado(mA,mB,mA2,mB2,"direita",1000);
 mudar_estado(mA,mB,mA2,mB2,"frente",8000);
 mudar_estado(mA,mB,mA2,mB2,"tras",3000);
  mudar_estado(mA,mB,mA2,mB2,"parado",10000);
 
}