// C++ code
#define led 4
#define botao 3
int bntclicado= 0;
int bntliberado=0;
int bntl3=0;
int bntc3=0;
#define botao2 2
#define led2 5
#define red 6
#define blue 7
#define green 8
#define maximo 3
#define b3 9
int ciclo =0;

void troca(){
  if(digitalRead(led)==HIGH){
    digitalWrite(led,LOW);
  }else{
    digitalWrite(led,HIGH);
  }
}
  void key(){
    if(bntclicado==1 and bntliberado==1){
      bntclicado=0;
      bntliberado=0;
      troca();
    }
  }
void vermelho(){
 digitalWrite(red,HIGH);
  digitalWrite(blue,LOW);
  digitalWrite(green,LOW);
}
void azul(){
 digitalWrite(red,LOW);
  digitalWrite(blue,HIGH);
  digitalWrite(green,LOW);
}
void verde(){
 digitalWrite(red,LOW);
  digitalWrite(blue,LOW);
  digitalWrite(green,HIGH);
}
void escolha(){
  if(ciclo==0){
   vermelho(); 
  }else if(ciclo==1){
   azul(); 
  }else if(ciclo==2){
   verde(); 
  }
  ciclo++;
  if(ciclo>maximo-1){
   ciclo=0; 
  }
}
void feitoTroca(){
  if(digitalRead(b3)==HIGH){
    bntl3=0;
    bntc3=1;
  }
  else{
   bntl3=1;
  }
  if(bntl3==1 and bntc3 ==1){
   bntl3=0;
    bntc3=0;
    escolha();
  }
}
void setup()
{
  pinMode(red,OUTPUT);
  pinMode(blue,OUTPUT);
  pinMode(green,OUTPUT);
  pinMode(b3,INPUT);
  pinMode(led, OUTPUT);
  pinMode(botao,INPUT);
  pinMode(botao2,INPUT);
  pinMode(led2,OUTPUT);
}

  
void loop()
{
  feitoTroca();
  if (digitalRead(botao)==HIGH){
	bntclicado=1;
    bntliberado=0;
  }else{
    bntliberado=1;
  }
  key();
  if(digitalRead(botao2)==HIGH){
   digitalWrite(led2,HIGH); 
  }else{
   digitalWrite(led2,LOW); 
  }
 }