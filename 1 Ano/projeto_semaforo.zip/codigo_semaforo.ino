// C++ code
//
#define vermelho 4
#define amarelo 3
#define verde 2
#define varia 5
void setup()
{
  pinMode(varia,OUTPUT);
  pinMode(vermelho, OUTPUT);
  pinMode(amarelo,OUTPUT);
  pinMode(verde,OUTPUT);
}
void verme(){
 digitalWrite(vermelho, HIGH);
 digitalWrite(amarelo,LOW);
 digitalWrite(verde,LOW); 
}
void amare(){
 digitalWrite(vermelho, LOW);
 digitalWrite(amarelo,HIGH);
 digitalWrite(verde,LOW); 
}
void ver(){
 digitalWrite(vermelho, LOW);
 digitalWrite(amarelo,LOW);
 digitalWrite(verde,HIGH); 
}
void loop()
{
  verme();
  delay(1000);
  amare();
  delay(1000);
  ver();
  delay(1000);
  for(int i=0; i<255;i++){
	analogWrite(varia,i);
    delay(10);
  }
  for(int i=255; i>0;i--){
   analogWrite(varia,i);
    delay(10);
  }
}