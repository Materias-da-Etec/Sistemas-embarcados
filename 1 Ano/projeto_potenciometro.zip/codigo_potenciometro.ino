int array[] = {2,3,4,5,6,7};
#define pot A5
void setup()
{
  pinMode(pot,INPUT);
  for(int i=0; i<6;i++){
    pinMode(array[i],OUTPUT);
  }
}
  void Acender(int x){
    for(int i=0; i<x;i++){
     digitalWrite(array[i],HIGH); 
    }
    for(int i=0;i<6;i++){
     digitalWrite(array[i],LOW); 
    }
  }

void loop()
{
  int val = analogRead(pot);
  Acender(map(val,0,1023,0,6));
}